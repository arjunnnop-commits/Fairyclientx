package com.fairyteam.fairyclient.brom

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Reads an "AllInOne" MediaTek DA container (MTK_AllInOne_DA.bin) so the right
 * loader is picked automatically from the chip's hardware code — this is what
 * SP Flash Tool does when you hand it a DA.
 */
class DaLoader(private val data: ByteArray) {

    data class Region(val buf: Long, val len: Long, val addr: Long, val offset: Long, val sigLen: Long)
    data class Entry(val hwCode: Int, val regions: List<Region>)

    val isContainer: Boolean =
        data.size > 0x70 && String(data, 0, 18, Charsets.US_ASCII) == "MTK_DOWNLOAD_AGENT"

    fun entries(): List<Entry> {
        if (!isContainer) return emptyList()
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val count = bb.getInt(0x68)
        if (count !in 1..64) return emptyList()
        val out = mutableListOf<Entry>()
        for (i in 0 until count) {
            val base = 0x6C + i * 0xDC
            if (base + 0xDC > data.size) break
            if ((bb.getShort(base).toInt() and 0xFFFF) != 0xDADA) continue
            val hw = bb.getShort(base + 2).toInt() and 0xFFFF
            val regionCount = (bb.getShort(base + 18).toInt() and 0xFFFF).coerceIn(0, 10)
            val regions = (0 until regionCount).map { r ->
                val o = base + 20 + r * 20
                Region(
                    bb.getInt(o).toLong() and 0xFFFFFFFFL,
                    bb.getInt(o + 4).toLong() and 0xFFFFFFFFL,
                    bb.getInt(o + 8).toLong() and 0xFFFFFFFFL,
                    bb.getInt(o + 12).toLong() and 0xFFFFFFFFL,
                    bb.getInt(o + 16).toLong() and 0xFFFFFFFFL
                )
            }
            out += Entry(hw, regions)
        }
        return out
    }

    fun find(hwCode: Int): Entry? = entries().firstOrNull { it.hwCode == hwCode }

    fun bytes(r: Region): ByteArray {
        val start = r.buf.toInt()
        val end = start + r.len.toInt()
        require(start >= 0 && end <= data.size) { "DA region out of file bounds" }
        return data.copyOfRange(start, end)
    }
}
