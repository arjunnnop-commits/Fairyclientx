package com.fairyteam.fairyclient.brom

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.SystemClock
import com.fairyteam.fairyclient.fastboot.FastbootClient
import com.fairyteam.fairyclient.usb.UsbLink
import com.fairyteam.fairyclient.usb.UsbPermissions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File

enum class Mode { FASTBOOT, DA }
enum class Phase { IDLE, WAITING, CONNECTING, WORKING, DONE, WARN, FAILED }

data class FlashJob(val mode: Mode, val da: File?, val boot: File?, val vendorBoot: File?)

/**
 * SP-Flash-Tool-style "arm it and plug the phone in" pipeline.
 *
 *  - polls USB every ~15 ms, grabs the MediaTek device the moment it shows up
 *    (any PID, survives re-enumeration: 0003 BROM / 2000 / 20FF Preloader …)
 *  - FASTBOOT mode: forces the bootloader, then flashes via fastboot
 *  - DA mode: handshake → hw code → security flags → DA1 upload → jump
 */
class AutoFlow(
    private val usb: UsbManager,
    private val perms: UsbPermissions,
    private val log: (String) -> Unit,
    private val onPhase: (Phase, String, String) -> Unit,
    private val onProgress: (Int) -> Unit
) {
    private enum class Kind { DONE, WARN, ABORT, RETRY }
    private data class Outcome(val kind: Kind, val title: String, val sub: String)

    companion object {
        const val MTK_VID = 0x0E8D
        const val PID_BROM = 0x0003
        private const val DA1_FALLBACK_ADDR = 0x200000L

        fun pidName(pid: Int) = when (pid) {
            0x0003 -> "BROM"
            0x2000, 0x20FF -> "Preloader"
            0x2001 -> "DA/Download"
            else -> "MediaTek"
        }
    }

    suspend fun run(job: FlashJob) {
        var attempt = 0
        while (currentCoroutineContext().isActive) {
            onProgress(0)
            onPhase(
                Phase.WAITING, "Waiting for device…",
                if (job.mode == Mode.FASTBOOT) "Connect the phone in BROM / Preloader mode"
                else "Connect the phone in BROM mode"
            )
            val dev = waitForDevice(job.mode)
            attempt++
            onPhase(Phase.CONNECTING, "Device caught", "${pidName(dev.productId)} · PID 0x${dev.productId.toString(16)} · try #$attempt")

            val out = try {
                withContext(Dispatchers.IO) { handle(dev, job) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log("Error: ${e.message}")
                Outcome(Kind.RETRY, "Error", e.message ?: "unknown")
            }

            when (out.kind) {
                Kind.DONE -> { onProgress(100); onPhase(Phase.DONE, out.title, out.sub); return }
                Kind.WARN -> { onPhase(Phase.WARN, out.title, out.sub); return }
                Kind.ABORT -> { onPhase(Phase.FAILED, out.title, out.sub); return }
                Kind.RETRY -> {
                    log("↻ ${out.title}: ${out.sub}")
                    onPhase(Phase.WAITING, "Retrying…", out.sub)
                    delay(400)
                }
            }
        }
    }

    // ---- device discovery ------------------------------------------------

    private suspend fun waitForDevice(mode: Mode): UsbDevice {
        while (true) {
            findDevice(mode)?.let { return it }
            delay(15)
        }
    }

    private fun findDevice(mode: Mode): UsbDevice? {
        val all = usb.deviceList.values
        if (mode == Mode.FASTBOOT) all.firstOrNull { FastbootClient.isFastbootDevice(it) }?.let { return it }
        return all.firstOrNull { it.vendorId == MTK_VID && !FastbootClient.isFastbootDevice(it) }
    }

    private suspend fun waitForFastboot(timeoutMs: Long): UsbDevice? {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < end) {
            usb.deviceList.values.firstOrNull { FastbootClient.isFastbootDevice(it) }?.let { return it }
            delay(30)
        }
        return null
    }

    /** Re-fetches the device by name each time: after re-enumeration old objects are stale. */
    private suspend fun openLink(dev: UsbDevice, accept: (android.hardware.usb.UsbInterface) -> Boolean = { true }): UsbLink? {
        repeat(60) {
            val cur = usb.deviceList[dev.deviceName] ?: return null
            val l = UsbLink(usb, cur, accept)
            if (l.open()) return l
            delay(20)
        }
        return null
    }

    // ---- dispatch --------------------------------------------------------

    private suspend fun handle(dev: UsbDevice, job: FlashJob): Outcome {
        if (!perms.ensure(dev)) {
            return Outcome(Kind.RETRY, "USB permission", "Not granted — allow it (tick “always”) and replug")
        }
        if (FastbootClient.isFastbootDevice(dev)) return flashViaFastboot(dev, job)
        return when (job.mode) {
            Mode.FASTBOOT -> forceBootloader(dev, job)
            Mode.DA -> daStage(dev, job)
        }
    }

    // ---- FASTBOOT mode ---------------------------------------------------

    private suspend fun forceBootloader(dev: UsbDevice, job: FlashJob): Outcome {
        if (dev.productId == PID_BROM) {
            return Outcome(
                Kind.ABORT, "True BROM detected",
                "Boot-mode request only works in Preloader. In BROM use DA mode."
            )
        }
        log("${pidName(dev.productId)} caught (PID 0x${dev.productId.toString(16)}) — forcing bootloader…")
        onPhase(Phase.WORKING, "Forcing bootloader", "Sending FASTBOOT request to preloader")
        onProgress(-1)

        val link = openLink(dev) ?: return Outcome(Kind.RETRY, "USB", "Could not open the device (it re-enumerated)")
        var seenRx = false
        var reenumerated = false
        try {
            val payload = "FASTBOOT".toByteArray(Charsets.US_ASCII)
            val end = SystemClock.elapsedRealtime() + 10000
            while (SystemClock.elapsedRealtime() < end) {
                if (usb.deviceList[dev.deviceName] == null) { reenumerated = true; break }
                link.write(payload, 40)
                val rx = link.readAvailable(64, 4)
                if (rx != null && rx.isNotEmpty() && !seenRx) {
                    seenRx = true
                    log("Preloader says: " + String(rx, Charsets.US_ASCII).filter { it.code in 32..126 })
                }
                delay(2)
            }
        } finally {
            link.close()
        }
        if (!reenumerated) {
            return Outcome(Kind.RETRY, "No reaction", "Preloader ignored the request — re-enter BROM/Preloader")
        }
        log("Device left preloader — waiting for fastboot…")
        val fb = waitForFastboot(25000)
            ?: return Outcome(Kind.RETRY, "No fastboot", "Device re-enumerated but no fastboot interface appeared")
        log("Fastboot device up (PID 0x${fb.productId.toString(16)}).")
        return handle(fb, job)
    }

    private suspend fun flashViaFastboot(dev: UsbDevice, job: FlashJob): Outcome {
        onPhase(Phase.WORKING, "Fastboot connected", "Reading bootloader info")
        onProgress(-1)
        val link = openLink(dev) { FastbootClient.isFastbootInterface(it) }
            ?: return Outcome(Kind.RETRY, "USB", "Could not open fastboot interface")
        try {
            val fb = FastbootClient(link, log)
            fb.getvar("product")?.let { log("product: $it") }
            fb.getvar("current-slot")?.let { log("slot: $it") }
            val unlocked = fb.getvar("unlocked")
            if (unlocked != null) log("unlocked: $unlocked")
            val maxDl = fb.getvar("max-download-size")?.removePrefix("0x")?.toLongOrNull(16)

            val images = listOfNotNull(
                job.boot?.let { "boot" to it },
                job.vendorBoot?.let { "vendor_boot" to it }
            )
            if (images.isEmpty()) {
                return Outcome(Kind.DONE, "Bootloader reached", "No images selected — device stays in fastboot")
            }
            images.firstOrNull { maxDl != null && it.second.length() > maxDl }?.let {
                return Outcome(Kind.ABORT, "Image too large", "${it.first} is bigger than max-download-size")
            }

            val total = images.sumOf { it.second.length() }.coerceAtLeast(1)
            var done = 0L
            for ((part, file) in images) {
                onPhase(Phase.WORKING, "Flashing $part", "${file.length() / 1024} KB")
                log("Flashing $part…")
                val base = done
                fb.flash(part, file) { sent -> onProgress(((base + sent) * 100 / total).toInt()) }
                done += file.length()
                log("$part OK")
            }
            onPhase(Phase.WORKING, "Rebooting", "")
            fb.reboot()
            return Outcome(Kind.DONE, "Flash complete", "Device is rebooting")
        } catch (e: FastbootClient.FastbootException) {
            val locked = e.message?.contains("lock", true) == true
            return Outcome(
                Kind.ABORT, "Fastboot error",
                (e.message ?: "unknown") + if (locked) "  — bootloader is locked" else ""
            )
        } finally {
            link.close()
        }
    }

    // ---- DA mode ---------------------------------------------------------

    private suspend fun daStage(dev: UsbDevice, job: FlashJob): Outcome {
        val daFile = job.da ?: return Outcome(Kind.ABORT, "No DA file", "Pick a DA file first")
        log("${pidName(dev.productId)} caught (PID 0x${dev.productId.toString(16)}) — handshaking…")
        onPhase(Phase.WORKING, "BROM handshake", "Tight polling, up to 20 s")
        onProgress(-1)

        val link = openLink(dev) ?: return Outcome(Kind.RETRY, "USB", "Could not open the device (it re-enumerated)")
        try {
            val brom = BromProtocol(link)
            if (!brom.handshake(20000)) {
                return Outcome(Kind.RETRY, "Handshake failed", "Device left the BROM window — replug in BROM mode")
            }
            log("Handshake OK.")

            val hw = brom.getHwCode()
            log("HW code: 0x${hw.toString(16)}")
            try {
                log("Security: " + brom.getTargetConfig())
            } catch (e: Exception) {
                log("Target config unavailable (${e.message})")
            }

            val loader = DaLoader(daFile.readBytes())
            val addr: Long
            val sigLen: Long
            val payload: ByteArray
            if (loader.isContainer) {
                val entry = loader.find(hw)
                    ?: return Outcome(Kind.ABORT, "DA mismatch", "This DA has no loader for chip 0x${hw.toString(16)}")
                val r = entry.regions.getOrNull(1)
                    ?: return Outcome(Kind.ABORT, "DA unreadable", "Loader entry has no stage-1 region")
                addr = r.addr; sigLen = r.sigLen; payload = loader.bytes(r)
                log("DA1: addr=0x${addr.toString(16)} len=${payload.size} sig=$sigLen")
            } else {
                addr = DA1_FALLBACK_ADDR; sigLen = 0; payload = daFile.readBytes()
                log("DA is not an AllInOne container — sending as raw DA1 @0x${addr.toString(16)}")
            }

            onPhase(Phase.WORKING, "Uploading DA", "${payload.size / 1024} KB")
            brom.sendDa(addr, payload, sigLen) { onProgress(it) }
            log("DA accepted.")
            brom.jumpDa(addr)
            log("Jumped to DA.")

            var sync = -1
            for (i in 0 until 4) {
                sync = link.readByte(if (i == 0) 8000 else 300)
                if (sync == 0xC0 || sync < 0) break
            }
            if (sync != 0xC0) {
                return Outcome(Kind.ABORT, "DA did not start", "No sync byte after jump — wrong DA for this chip")
            }
            log("DA1 is running (sync 0xC0).")
            val wanted = listOfNotNull(job.boot?.let { "boot" }, job.vendorBoot?.let { "vendor_boot" })
            return Outcome(
                Kind.WARN, "DA stage 1 OK",
                if (wanted.isEmpty()) "Chip talks to the DA. Partition writing is not implemented in-app yet."
                else "Partition writing (${wanted.joinToString()}) is not implemented in DA mode — use FASTBOOT mode."
            )
        } catch (e: BromProtocol.BromException) {
            return Outcome(Kind.ABORT, "BROM error", e.message ?: "unknown")
        } finally {
            link.close()
        }
    }
}
