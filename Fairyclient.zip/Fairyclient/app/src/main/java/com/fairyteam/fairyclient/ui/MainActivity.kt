package com.fairyteam.fairyclient.ui

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fairyteam.fairyclient.R
import com.fairyteam.fairyclient.brom.AutoFlow
import com.fairyteam.fairyclient.brom.FlashJob
import com.fairyteam.fairyclient.brom.Mode
import com.fairyteam.fairyclient.brom.Phase
import com.fairyteam.fairyclient.data.FileStore
import com.fairyteam.fairyclient.data.Kind
import com.fairyteam.fairyclient.databinding.ActivityMainBinding
import com.fairyteam.fairyclient.usb.UsbPermissions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var usb: UsbManager
    private lateinit var perms: UsbPermissions
    private lateinit var store: FileStore
    private lateinit var flow: AutoFlow

    private var armJob: Job? = null
    private var mode = Mode.FASTBOOT
    private val logLines = ArrayDeque<String>()

    private val pickers = Kind.values().associateWith { kind ->
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importFile(kind, uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        store = FileStore(this)
        perms = UsbPermissions(this, usb)
        perms.register()
        flow = AutoFlow(usb, perms, ::log, ::showPhase, ::showProgress)

        b.btnPickDa.setOnClickListener { pickers[Kind.DA]?.launch(arrayOf("*/*")) }
        b.btnPickBoot.setOnClickListener { pickers[Kind.BOOT]?.launch(arrayOf("*/*")) }
        b.btnPickVendorBoot.setOnClickListener { pickers[Kind.VENDOR_BOOT]?.launch(arrayOf("*/*")) }
        b.btnArm.setOnClickListener { toggleArm() }
        b.btnClear.setOnClickListener {
            if (armJob?.isActive != true) {
                store.clear(); refreshFiles(); log("Saved files cleared.")
            }
        }

        b.toggleMode.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                mode = if (id == R.id.btnModeDa) Mode.DA else Mode.FASTBOOT
                styleModeButtons(); refreshFiles()
            }
        }
        b.toggleMode.check(R.id.btnModeFastboot)
        styleModeButtons()
        refreshFiles()
        showProgress(0)
        log("Ready. Pick the images once, press START AUTO, then plug the phone in.")
        log("Tip: when Android asks what to open for the USB device, choose Fairyclient and tick “Use by default” — after that there is no popup.")

        // Launched by the phone itself being plugged in → arm immediately.
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) startArm()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED && armJob?.isActive != true) startArm()
    }

    // ---- arming ----------------------------------------------------------

    private fun toggleArm() {
        if (armJob?.isActive == true) armJob?.cancel() else startArm()
    }

    private fun startArm() {
        val da = store.file(Kind.DA)
        if (mode == Mode.DA && da == null) {
            showPhase(Phase.FAILED, "DA file missing", "DA mode needs a DA file — tap Select.")
            return
        }
        val job = FlashJob(mode, da, store.file(Kind.BOOT), store.file(Kind.VENDOR_BOOT))
        setArmed(true)
        armJob = lifecycleScope.launch {
            try {
                flow.run(job)
            } catch (e: CancellationException) {
                showPhase(Phase.IDLE, "Stopped", "Press START AUTO to arm again.")
                showProgress(0)
                throw e
            } finally {
                setArmed(false)
            }
        }
    }

    private fun setArmed(armed: Boolean) {
        b.btnArm.text = if (armed) "STOP" else "START AUTO"
        b.btnArm.backgroundTintList = ColorStateList.valueOf(Color.parseColor(if (armed) "#FF5C5C" else "#00FF66"))
        b.toggleMode.isEnabled = !armed
        b.btnModeFastboot.isEnabled = !armed
        b.btnModeDa.isEnabled = !armed
        if (armed) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---- files -----------------------------------------------------------

    private fun importFile(kind: Kind, uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { store.import(kind, uri) }
            log(if (ok) "${kind.label} saved." else "Could not read ${kind.label}.")
            refreshFiles()
        }
    }

    private fun refreshFiles() {
        fun set(tv: TextView, k: Kind) {
            val d = store.describe(k)
            tv.text = d ?: "not selected"
            tv.setTextColor(Color.parseColor(if (d != null) "#00FF66" else "#8A93A3"))
        }
        set(b.tvDaName, Kind.DA)
        set(b.tvBootName, Kind.BOOT)
        set(b.tvVendorBootName, Kind.VENDOR_BOOT)
        b.lblDa.text = if (mode == Mode.DA) "DA file  (required)" else "DA file  (DA mode only)"
    }

    private fun styleModeButtons() {
        for (btn in listOf(b.btnModeFastboot, b.btnModeDa)) {
            val on = btn.isChecked
            btn.backgroundTintList = ColorStateList.valueOf(Color.parseColor(if (on) "#00FF66" else "#00000000"))
            btn.setTextColor(Color.parseColor(if (on) "#000000" else "#FFFFFF"))
        }
    }

    // ---- UI callbacks (safe from any thread) -----------------------------

    private fun ui(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else runOnUiThread { block() }
    }

    private fun log(line: String) = ui {
        logLines.addLast(line)
        while (logLines.size > 400) logLines.removeFirst()
        b.consoleText.text = logLines.joinToString("\n")
        b.consoleScroll.post { b.consoleScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    private fun showPhase(p: Phase, title: String, sub: String) = ui {
        b.tvStatus.text = title
        b.tvStatusSub.text = sub
        val c = when (p) {
            Phase.DONE -> "#00FF66"
            Phase.WARN -> "#FFB020"
            Phase.FAILED -> "#FF5C5C"
            Phase.WORKING, Phase.CONNECTING -> "#4DA3FF"
            else -> "#E6E8EC"
        }
        b.tvStatus.setTextColor(Color.parseColor(c))
    }

    /** -1 = indeterminate, 0..100 = percent. */
    private fun showProgress(pct: Int) = ui {
        if (pct < 0) {
            if (!b.progress.isIndeterminate) b.progress.isIndeterminate = true
        } else {
            if (b.progress.isIndeterminate) b.progress.isIndeterminate = false
            b.progress.setProgressCompat(pct.coerceIn(0, 100), false)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        perms.unregister()
    }
}
