package com.fairyteam.fairyclient.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap

/**
 * One place that deals with Android's USB permission.
 *
 * Android never lets a normal app skip the consent step, BUT when the app is
 * launched through the USB_DEVICE_ATTACHED intent (manifest) and the user
 * ticked "Use by default", the grant is automatic and there is no popup at
 * all. [ensure] therefore first checks hasPermission() and only asks if it
 * really has to.
 */
class UsbPermissions(private val ctx: Context, private val usb: UsbManager) {

    private val action = ctx.packageName + ".USB_PERMISSION"
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            val dev = deviceFrom(intent) ?: return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            waiters.remove(dev.deviceName)?.complete(granted)
        }
    }

    fun register() {
        ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    fun unregister() {
        try {
            ctx.unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
    }

    suspend fun ensure(dev: UsbDevice, timeoutMs: Long = 30000): Boolean {
        if (usb.hasPermission(dev)) return true
        val d = CompletableDeferred<Boolean>()
        waiters[dev.deviceName] = d

        // Must be explicit (setPackage) + mutable on Android 14, otherwise
        // requestPermission() throws / the result never comes back.
        val intent = Intent(action).setPackage(ctx.packageName)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        else PendingIntent.FLAG_UPDATE_CURRENT
        val pi = PendingIntent.getBroadcast(ctx, 0, intent, flags)
        try {
            usb.requestPermission(dev, pi)
        } catch (e: Exception) {
            waiters.remove(dev.deviceName)
            return false
        }
        var granted: Boolean? = null
        withTimeoutOrNull(timeoutMs) {
            while (granted == null) {
                if (usb.hasPermission(dev)) granted = true
                else if (d.isCompleted) granted = d.await()
                else delay(25)
            }
        }
        waiters.remove(dev.deviceName)
        return granted == true
    }

    companion object {
        fun deviceFrom(intent: Intent): UsbDevice? =
            if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            else
                @Suppress("DEPRECATION") intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
    }
}
