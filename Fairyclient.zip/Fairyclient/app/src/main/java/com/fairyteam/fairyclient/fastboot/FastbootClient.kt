package com.fairyteam.fairyclient.fastboot

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbInterface
import android.os.SystemClock
import com.fairyteam.fairyclient.usb.UsbLink
import java.io.File
import java.io.FileInputStream

/** Standard Android fastboot protocol (ASCII commands over one bulk pipe). */
class FastbootClient(private val link: UsbLink, private val log: (String) -> Unit) {

    class FastbootException(message: String) : Exception(message)

    companion object {
        fun isFastbootInterface(i: UsbInterface) =
            i.interfaceClass == 0xFF && i.interfaceSubclass == 0x42 && i.interfaceProtocol == 0x03

        fun isFastbootDevice(d: UsbDevice): Boolean =
            (0 until d.interfaceCount).any { isFastbootInterface(d.getInterface(it)) }
    }

    fun command(cmd: String, timeoutMs: Int = 10000): String {
        if (!link.write(cmd.toByteArray(Charsets.US_ASCII), 3000))
            throw FastbootException("USB write failed ($cmd)")
        return readResponse(timeoutMs)
    }

    fun getvar(name: String): String? = try {
        command("getvar:$name", 3000)
    } catch (e: FastbootException) {
        null
    }

    private fun readResponse(timeoutMs: Int): String {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (true) {
            val left = (deadline - SystemClock.elapsedRealtime()).toInt()
            if (left <= 0) throw FastbootException("Bootloader did not answer in time")
            val r = link.readAvailable(512, minOf(left, 1000)) ?: continue
            val s = String(r, Charsets.US_ASCII)
            when {
                s.startsWith("INFO") || s.startsWith("TEXT") -> log("   " + s.substring(4).trim())
                s.startsWith("OKAY") -> return s.substring(4)
                s.startsWith("DATA") -> return s
                s.startsWith("FAIL") -> throw FastbootException(s.substring(4).ifBlank { "unknown error" })
                else -> throw FastbootException("Unexpected reply: $s")
            }
        }
    }

    fun download(file: File, onBytes: (Long) -> Unit) {
        val size = file.length()
        val resp = command("download:%08x".format(size), 10000)
        if (!resp.startsWith("DATA")) throw FastbootException("Bootloader refused download")
        val buf = ByteArray(65536)
        var sent = 0L
        FileInputStream(file).use { input ->
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                if (!link.writeN(buf, n, 20000)) throw FastbootException("USB write failed at $sent / $size")
                sent += n
                onBytes(sent)
            }
        }
        readResponse(60000)
    }

    fun flash(partition: String, file: File, onBytes: (Long) -> Unit) {
        download(file, onBytes)
        command("flash:$partition", 180000)
    }

    fun reboot() {
        try {
            command("reboot", 3000)
        } catch (_: Exception) {
        }
    }
}
