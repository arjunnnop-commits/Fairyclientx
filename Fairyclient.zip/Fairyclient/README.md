# Fairyclient

MediaTek BROM / Preloader recovery for Android (USB-OTG, no root).

* **Force bootloader** mode: catches the Preloader, asks it for fastboot, then flashes
  boot / vendor_boot with the standard fastboot protocol.
* **DA / BROM** mode: handshake, chip id, security flags (SBC/SLA/DAA), picks the right
  loader from an AllInOne DA automatically, uploads DA1 and jumps to it.
  (Partition writing through the DA is not implemented.)

Pick files once (they are stored privately), press START AUTO, plug the phone in.

First plug-in: choose Fairyclient in Android's USB dialog and tick "Use by default" —
afterwards the app opens with permission already granted (no popup).
